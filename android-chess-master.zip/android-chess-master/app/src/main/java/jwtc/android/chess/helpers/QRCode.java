package jwtc.android.chess.helpers;

public class QRCode {
    /*
    case R.id.action_from_qrcode:
                try {
                    intent = new Intent("com.google.zxing.client.android.SCAN");
                    //com.google.zxing.client.android.SCAN.
                    intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
                    startActivityForResult(intent, REQUEST_FROM_QR_CODE);
                } catch (Exception ex) {
                    doToast(getString(R.string.err_install_barcode_scanner));
                }
                return true;
            case R.id.action_to_qrcode:
                s = "http://chart.apis.google.com/chart?chs=200x200&cht=qr&chl=";
                s += java.net.URLEncoder.encode(_chessView.getJNI().toFEN());
                copyToClipBoard(s);
                doToast(getString(R.string.msg_qr_code_on_clipboard));
                return true;
     */
}
